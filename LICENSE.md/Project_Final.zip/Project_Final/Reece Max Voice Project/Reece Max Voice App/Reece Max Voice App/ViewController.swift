//
//  ViewController.swift
//  Reece Max Voice App
//  Team 25: Alush Selimi, Abdulrahman Baali, Hong Wey, Vasu Batra, Weiqi Zhang & Xueting Jiang
//
//
//  Created by Alush Selimi on 18/6/18.
//  Copyright © 2018 deakin. All rights reserved.
//

// import libraries
import UIKit
import MapKit
import CoreLocation
import Speech
import CoreML
import Foundation
import AVFoundation
import Firebase

// code for language classifier: search through strings as well as split and match them
public class re {
    public static func compile(_ pattern: String, flags: RegexObject.Flag = []) -> RegexObject  {
        return RegexObject(pattern: pattern, flags: flags)
    }
    
    public static func search(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
        return re.compile(pattern, flags: flags).search(string)
    }
    
    public static func match(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> MatchObject? {
        return re.compile(pattern, flags: flags).match(string)
    }
    
    public static func split(_ pattern: String, _ string: String, _ maxsplit: Int = 0, flags: RegexObject.Flag = []) -> [String?] {
        return re.compile(pattern, flags: flags).split(string, maxsplit)
    }
    
    public static func findall(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [String] {
        return re.compile(pattern, flags: flags).findall(string)
    }
    
    public static func finditer(_ pattern: String, _ string: String, flags: RegexObject.Flag = []) -> [MatchObject] {
        return re.compile(pattern, flags: flags).finditer(string)
    }
    
    public static func sub(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> String {
        return re.compile(pattern, flags: flags).sub(repl, string, count)
    }
    
    public static func subn(_ pattern: String, _ repl: String, _ string: String, _ count: Int = 0, flags: RegexObject.Flag = []) -> (String, Int) {
        return re.compile(pattern, flags: flags).subn(repl, string, count)
    }
    
    public class RegexObject {
        /// Typealias for NSRegularExpressionOptions
        public typealias Flag = NSRegularExpression.Options
        
        /// Whether this object is valid or not
        public var isValid: Bool {
            return regex != nil
        }
        
        /// Pattern used to construct this RegexObject
        public let pattern: String
        
        private let regex: NSRegularExpression?
        
        /// Underlying NSRegularExpression Object
        public var nsRegex: NSRegularExpression? {
            return regex
        }
        
        /// NSRegularExpressionOptions used to contructor this RegexObject
        public var flags: Flag {
            return regex?.options ?? []
        }
        
        /// Number of capturing groups
        public var groups: Int {
            return regex?.numberOfCaptureGroups ?? 0
        }
        
        public required init(pattern: String, flags: Flag = [])  {
            self.pattern = pattern
            do {
                self.regex = try NSRegularExpression(pattern: pattern, options: flags)
            } catch let error as NSError {
                self.regex = nil
                debugPrint(error)
            }
        }
        // function to search through the strings and match according to regular expression
        public func search(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil, options: NSRegularExpression.MatchingOptions = []) -> MatchObject? {
            guard let regex = regex else {
                return nil
            }
            let start = pos > 0 ?pos :0
            let end = endpos ?? string.utf16.count
            let length = max(0, end - start)
            let range = NSRange(location: start, length: length)
            if let match = regex.firstMatch(in: string, options: options, range: range) {
                return MatchObject(string: string, match: match)
            }
            return nil
        }
        // function to match strings
        public func match(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> MatchObject? {
            return search(string, pos, endpos, options: [.anchored])
        }
        
        // function to split strings
        public func split(_ string: String, _ maxsplit: Int = 0) -> [String?] {
            guard let regex = regex else {
                return []
            }
            var splitsLeft = maxsplit == 0 ? Int.max : (maxsplit < 0 ? 0 : maxsplit)
            let range = NSRange(location: 0, length: string.utf16.count)
            var results = [String?]()
            var start = string.startIndex
            var end = string.startIndex
            regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                if splitsLeft <= 0 {
                    stop.pointee = true
                    return
                }
                
                guard let result = result, result.range.length > 0 else {
                    return
                }
                
                end = string.characters.index(string.startIndex, offsetBy: result.range.location)
                results.append(String(string[start..<end]))
                if regex.numberOfCaptureGroups > 0 {
                    results += MatchObject(string: string, match: result).groups()
                }
                splitsLeft -= 1
                start = string.index(end, offsetBy: result.range.length)
            }
            if start <= string.endIndex {
                results.append(String(string[start..<string.endIndex]))
            }
            return results
        }
        
        // function to find all matches
        public func findall(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [String] {
            return finditer(string, pos, endpos).map { $0.group()! }
        }
        
        // function to find iterations
        public func finditer(_ string: String, _ pos: Int = 0, _ endpos: Int? = nil) -> [MatchObject] {
            guard let regex = regex else {
                return []
            }
            let start = pos > 0 ?pos :0
            let end = endpos ?? string.utf16.count
            let length = max(0, end - start)
            let range = NSRange(location: start, length: length)
            return regex.matches(in: string, options: [], range: range).map { MatchObject(string: string, match: $0) }
        }
        
        public func sub(_ repl: String, _ string: String, _ count: Int = 0) -> String {
            return subn(repl, string, count).0
        }
        
        public func subn(_ repl: String, _ string: String, _ count: Int = 0) -> (String, Int) {
            guard let regex = regex else {
                return (string, 0)
            }
            let range = NSRange(location: 0, length: string.utf16.count)
            let mutable = NSMutableString(string: string)
            let maxCount = count == 0 ? Int.max : (count > 0 ? count : 0)
            var n = 0
            var offset = 0
            regex.enumerateMatches(in: string, options: [], range: range) { result, _, stop in
                if maxCount <= n {
                    stop.pointee = true
                    return
                }
                if let result = result {
                    n += 1
                    let resultRange = NSRange(location: result.range.location + offset, length: result.range.length)
                    let lengthBeforeReplace = mutable.length
                    regex.replaceMatches(in: mutable, options: [], range: resultRange, withTemplate: repl)
                    offset += mutable.length - lengthBeforeReplace
                }
            }
            return (mutable as String, n)
        }
    }
    
    public final class MatchObject {
        /// String matched
        public let string: String
        
        /// Underlying NSTextCheckingResult
        public let match: NSTextCheckingResult
        
        init(string: String, match: NSTextCheckingResult) {
            self.string = string
            self.match = match
        }
        
        // function to expand string according to regular expression
        public func expand(_ template: String) -> String {
            guard let regex = match.regularExpression else {
                return ""
            }
            return regex.replacementString(for: match, in: string, offset: 0, template: template)
        }
        
        // function to group strings
        public func group(_ index: Int = 0) -> String? {
            guard let range = span(index), range.lowerBound < string.endIndex else {
                return nil
            }
            return String(string[range])
        }
        
        public func group(_ indexes: [Int]) -> [String?] {
            return indexes.map { group($0) }
        }
        
        public func groups(_ defaultValue: String) -> [String] {
            return (1..<match.numberOfRanges).map { group($0) ?? defaultValue }
        }
        
        public func groups() -> [String?] {
            return (1..<match.numberOfRanges).map { group($0) }
        }
        
        public func span(_ index: Int = 0) -> Range<String.Index>? {
            if index >= match.numberOfRanges {
                return nil
            }
            let nsrange = match.range(at: index)
            
            if nsrange.location == NSNotFound {
                return string.endIndex..<string.endIndex
            }
            let startIndex16 = string.utf16.index(string.startIndex, offsetBy: nsrange.location)
            let endIndex16 = string.utf16.index(startIndex16, offsetBy: nsrange.length)
            return (String.Index(startIndex16, within: string) ?? string.endIndex)..<(String.Index(endIndex16, within: string) ?? string.endIndex)
        }
    }
}


class ViewController : UIViewController, CLLocationManagerDelegate, SFSpeechRecognizerDelegate, MKMapViewDelegate {

    // variable to count route steps
    var steps = [MKRouteStep]()
    
    // speech synthesizer to read directions to user
    let speechSynth = AVSpeechSynthesizer()
    
    // step counter
    var stepCounter = 0
    
    // reference to the firebase database
    var Branches: DatabaseReference!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Initialise location, buttons,the map overlay, and background colour as well as database references
        mapView.removeOverlays(mapView.overlays)
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        view.backgroundColor = UIColor.white //(red: 0, green: 0.1843, blue: 0.5882, alpha: 1.0)
        textField.layer.cornerRadius = 5
        textField.backgroundColor = UIColor.white //(red: 0, green: 0.1843, blue: 0.5882, alpha: 1.0)
        textField.textColor = UIColor(red: 0.0275, green: 0.4627, blue: 0.6667, alpha: 1)
        talkButton2.layer.cornerRadius = 10
        talkButton2.clipsToBounds = true
        talkButton2.backgroundColor = UIColor(red: 0, green: 0.4882, blue: 1, alpha: 1)
        locationManager.delegate = self as CLLocationManagerDelegate
        locationManager.requestWhenInUseAuthorization()
        talkButton2.isEnabled = false
        speechRecognizer?.delegate = self
        
        // database reference
        Branches = Database.database().reference()
        
        // load in all data and store in relevant branch object
        Branches.observe(DataEventType.value, with: {(DataSnapshot) in
            
            for branch in DataSnapshot.children.allObjects as! [DataSnapshot] {
                let branchObject = branch.value as? [String: AnyObject]
                let brAddress = branchObject?["Address"]
                let brName = branchObject?["Branch Name"]
                let BrPhNo = branchObject?["Branch Ph No"]
                let BrLat = branchObject?["Latitude"]
                let BrLong = branchObject?["Longitude"]
                let BrManager = branchObject?["Manager"]
                let BrPostcode = branchObject?["Postcode"]
                let BrState = branchObject?["State"]
                let BrSuburb = branchObject?["Suburb"]
                
                
                // store all data in the branch data model
                _ = BranchModel(Address: brAddress as! String?, BranchName: brName as! String?, BranchPhNo: BrPhNo as! String?, Lat: BrLat as! String?, Long: BrLong as! String?, Manager: BrManager as! String?, Postcode: BrPostcode as! String?, State: BrState as! String?, Suburb: BrSuburb as! String?)
            }
            
        })
        
        // class for branch data model
        class BranchModel {
            var Address: String?
            var BranchName: String?
            var BranchPhNo: String?
            var Lat: String?
            var Long: String?
            var Manager: String?
            var Postcode: String?
            var State: String?
            var Suburb: String?
            
            // constructor
            init(Address: String?, BranchName: String?, BranchPhNo: String?, Lat: String?, Long: String?, Manager: String?, Postcode: String?, State: String?, Suburb: String?)
            {
                self.Address = Address
                self.BranchName = BranchName
                self.BranchPhNo = BranchPhNo
                self.Lat = Lat
                self.Long = Long
                self.Manager = Manager
                self.Postcode = Postcode
                self.State = State
                self.Suburb = Suburb
            }
        }
        
        
        
       
        // Do any additional setup after loading the view, typically from a nib.
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            
            var isButtonEnabled = false
            
            switch authStatus {
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("Access Denied")
                
            case .restricted:
                isButtonEnabled = false
                print("Restricted")
                
            case .notDetermined:
                isButtonEnabled = false
                print("not yet authorized")
            }
            
            OperationQueue.main.addOperation() {
                self.talkButton2.isEnabled = isButtonEnabled
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // function to find city to determine distance from suburb to store
    func fetchCityAndCountry(location: CLLocation, completion: @escaping (_ city: String?, _ country:  String?, _ error: Error?) -> ()) {
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            completion(placemarks?.first?.locality,
                       placemarks?.first?.country,
                       error)
        }
    }
    
    
    
    // function to draw route on map from users location to store location and read out directions
    func ShowRoute(sourceCoordinate: CLLocationCoordinate2D, destiCoordinate: CLLocationCoordinate2D)
    {
        mapView.delegate = self
        
        let request = MKDirectionsRequest()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: sourceCoordinate, addressDictionary: nil))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destiCoordinate, addressDictionary: nil))
        request.requestsAlternateRoutes = true
        request.transportType = .automobile
        
        let directions = MKDirections(request: request)
        
        directions.calculate { [unowned self] response, error in
            guard let unwrappedResponse = response else { return }
            
            if (unwrappedResponse.routes.count > 0) {
                self.mapView.add(unwrappedResponse.routes[0].polyline, level: MKOverlayLevel.aboveRoads)
                self.mapView.setVisibleMapRect(unwrappedResponse.routes[0].polyline.boundingMapRect, animated: true)
                self.steps = unwrappedResponse.routes[0].steps
                for i in 0..<unwrappedResponse.routes[0].steps.count {
                    let step = unwrappedResponse.routes[0].steps[i]
                    print(step.instructions)
                    print(step.distance)
                    
                    self.textField.text = "\(step.instructions)"
                    
                    let region = CLCircularRegion(center: step.polyline.coordinate, radius: 20, identifier: "\(i)")
                    
                    self.locationManager.startMonitoring(for: region)
                    let circle = MKCircle(center: region.center, radius: region.radius)
                    self.mapView.add(circle)
                    
                        let initial = "\(step.instructions)"
                        let speech = AVSpeechUtterance(string: initial)
                        speech.voice = AVSpeechSynthesisVoice(language: "en_AU")
                        speech.postUtteranceDelay = 3.50
                        self.speechSynth.speak(speech)
                    
                }
            }
        }
    }
    
    // function to render line on map
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer
    {
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.blue
            polylineRenderer.lineWidth = 5
            return polylineRenderer
        }
        return MKOverlayRenderer()
    }
    

    
    
    
    // outlet declaration for mapview
    @IBOutlet weak var mapView: MKMapView!
    
    let locationManager = CLLocationManager()
    // determine users location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locations = locations[0]
        
        let center = locations.coordinate
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: center, span: span)
        
        mapView.setRegion(region, animated: true)
        mapView.showsUserLocation = true
        
        
    }
    // track regions
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("ENTERED")
        stepCounter += 1
        if stepCounter < steps.count {
            let currentStep = steps[stepCounter]
            let message = "In \(currentStep.distance) meters, \(currentStep.instructions)"
            self.textField.text = message
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynth.speak(speechUtterance)
        } else {
            let message = "Arrived at destination"
            self.textField.text = message
            let speechUtterance = AVSpeechUtterance(string: message)
            speechSynth.speak(speechUtterance)
            stepCounter = 0
            locationManager.monitoredRegions.forEach({self.locationManager.stopMonitoring(for: $0)})
        }
    }
    
    // outlet declarations
    @IBOutlet weak var textField: UITextView!
    var dataObject: String = ""
    @IBOutlet weak var dataLabel: UILabel!
    
    @IBOutlet weak var talkButton2: UIButton!

    // This button, when pressed, starts recording the users voice, also refreshes map.
    @IBAction func talkButton(_ sender: AnyObject) {
        mapView.removeOverlays(mapView.overlays)
        textField.text = ""
        self.speechSynth.stopSpeaking(at: AVSpeechBoundary.immediate)
        if audioEngine.isRunning {
            audioEngine.stop()
            recogntionRequest?.endAudio()
            talkButton2.isEnabled = false
            talkButton2.setTitle("Start Recording", for: .normal)
            
        } else {
            startRecording()
            talkButton2.setTitle("Stop Recording", for: .normal)
            
        }
    }
    
    @IBOutlet weak var infoBTN: UIButton!
    
    // This button, when pressed, displays help information via an alert for the user.
    @IBAction func infoButton(_ sender: AnyObject) {
        let alert = UIAlertController(title: "Help", message: "Tap the 'Speak' button to get started. \n Say things like: \n Take me to (suburb name) \n OR \n Call (suburb name) \n OR \n Store Info (suburb name) \n OR \n What is the closest store to (suburb name)"
            
            , preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Got it", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        speechSynth.stopSpeaking(at: AVSpeechBoundary.word)
    }
    
    // This button, when pressed, displays copyright/legal information
    @IBAction func maxButton(_ sender: AnyObject) {
        let alert = UIAlertController(title: "About", message: " By using this application, you agree to our terms of service. Your data is not being collected/stored and your location is only being tracked when the app is being used \nCopyright © Reece Max 2018. \n All rights reserved"
            
            
            , preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Got it", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    // Transcrption variables
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "en_AU"))
    private var recogntionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    
    // function that records what the user is saying
    func startRecording() {
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch
        {
            print("Session properties weren't set because of an error")
        }
        
        recogntionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        
        //Launches the audio engine service
        func applicationDidFinishLaunching(aNotification: NSNotification) {
            audioEngine.prepare()
            do{
                try audioEngine.start()
            } catch
            {
                print("Audio Engine Error")
            }
        }
        
        
        // determines whether the user has given their permission to use voice recognition
        guard let recognitionRequest = recogntionRequest else {
            fatalError("unable to create SFSpeechAudioBufferRecognitionRequest")
        }
        
        recogntionRequest?.shouldReportPartialResults = true
        // determines what the user is saying and displays it to the text field
        recognitionTask = speechRecognizer!.recognitionTask(with: recogntionRequest!, resultHandler: { (result, error) in
            var isFinal = false
            if result != nil {
                self.textField.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
            }
            
            if error != nil || isFinal {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recogntionRequest = nil
                self.recognitionTask = nil
                
                self.talkButton2.isEnabled  = true
            }
            
            
            // display test input to text field
            let test_input: String = "\(self.textField.text)"
            var test_output = ""
            
            // classifier: determine their intentions depending on what has been said
            var testing:[String: [[String:[String]]]] = [
                "intents":
                    [
                        ["intent":["Operation: location"],"utterances":["burwood","chadstone","blackburn","boxhill","dandenong"]],
                        ["intent":["Operation: call"],"utterances":["call","phone","ring","buzz","contact"]],
                        ["intent":["Operation: go"],"utterances":["go","navigate","direction","drive","take","lead"]],
                        ["intent":["Operation: info"], "utterances":
                            ["hours","trading","manager","branch","operating","open", "info"]],
                        ["intent":["Operation: closest"], "utterances":
                        ["nearest", "closest", "approximate", "proximity", "nearby",]]
                ]
            ]
            // set all test input to lowercase
            let to_lower_case = test_input.lowercased()
            let pre_mapper = re.sub("[+.!/_,$%^*)(+\"']+|[+——！，。？、~@#￥%……&*（）]+"," ",to_lower_case)
            //print("Pre Mapper : ",pre_mapper)
            //
            var mapper_out = [String]()
            // split mapper input
            let mapper_input = pre_mapper.split(separator: " ")
            
            //print("Mapper Input :",mapper_input)
            for word in mapper_input{
                if(word != ""){
                    let s = String(format: "%@ %d",word as CVarArg,1)
                    mapper_out.append(s)
                }
            }
            //print("Mapper Out : ",mapper_out)
            
            var current_word:String? = nil
            var current_count = 0
            var _:String? = nil
            
            var key_words = [String]()
            // for loop to go through words
            for line in mapper_out{
                let _line = line.trimmingCharacters(in:NSCharacterSet.whitespacesAndNewlines)
                var words = _line.split(separator: " ")
                let word = words[0]
                let count = Int(words[1])
                if (current_word == String(word)){
                    current_count += count!
                }
                else{
                    if (current_word != nil){
                        //            print ((current_word, current_count))
                        key_words.append(String(format: "%@", current_word!))
                    }
                    current_count = count!
                    current_word = String(word)
                }
            }
            
            
            
            // understand and act on what user is saying
            //print("Key Words: ",key_words)
            for key in testing.keys{
                for keys in testing[key]!{
                    for test in keys.keys{
                        if (test == "utterances"){
                            for tests in keys[test]!{
                                for keyword in key_words{
                                    if (keyword == tests.lowercased()){
                                        // Call X Store
                                        if(keys["intent"]![0] == "Operation: call"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0])
                                                                         print(s)
                                            test_output.append(contentsOf: s)
                                            // if user has asked to call said store, then call said store
                                            self.Branches.observe(DataEventType.value, with: {(DataSnapshot) in
                                                
                                                for branch in DataSnapshot.children.allObjects as! [DataSnapshot] {
                                                    
                                                    let branchObject = branch.value as? [String: AnyObject]
                                                    let BrPhNo = branchObject?["Branch Ph Number"]
                                                    let BrSuburb = branchObject?["Suburb"]
                                                    
                                                    // This prints true for the snapshot that contains that value
                                                    // try tag the location in test_input and use it in the brackets
                                                    let schemes = NSLinguisticTagger.availableTagSchemes(forLanguage: "en_AU")
                                                    let tagger = NSLinguisticTagger(tagSchemes: schemes, options: 0)
                                                    let text = self.textField.text
                                                    tagger.string = text
                                                    
                                                    let range = NSRange(location:0, length: (text?.utf16.count)!)
                                                    let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
                                                    let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
                                                    
                                                    tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
                                                        
                                                        if let tag = tag, tags.contains(tag) {
                                                            let name = (text as! NSString).substring(with: tokenRange)
                                                            // Do something with the name
                                                            if((BrSuburb)?.contains(name))!
                                                            {
                                                                _ = (self.Branches.queryOrdered(byChild: "\(name)").queryEqual(toValue: "\(name)"))
                                                                self.textField.text = "\(BrPhNo!)"
                                                                let myString = self.textField.text
                                                                let new = myString?.replacingOccurrences(of: " ", with: "")
                                                                let new2 = new?.replacingOccurrences(of: "(", with: "")
                                                                let new3 = new2?.replacingOccurrences(of: ")", with: "")
                                                                self.textField.text = "\(new3!)"
                                                                let urlP : NSURL = (NSURL(string: "tel://\(new3!)"))!
                                                                UIApplication.shared.canOpenURL(urlP as URL);  UIApplication.shared.open(urlP as URL)
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                            
                                        }
                                            
                                        // if the user has asked to be taken to a specific store, then take the user to that store
                                        else if (keys["intent"]![0]  == "Operation: go"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0])
                                                                            print(s)
                                            test_output.append(contentsOf: s)
                                            // NAVIGATION CODE HERE FROM CURRENT LOCATION TO STORE LOCATION
                                            // CALL X STORE
                                            
                                            let src = CLLocationCoordinate2DMake(self.mapView.userLocation.coordinate.latitude, self.mapView.userLocation.coordinate.longitude)
                                            self.Branches.observe(DataEventType.value, with: {(DataSnapshot) in
                                                
                                                for branch in DataSnapshot.children.allObjects as! [DataSnapshot] {
                                                    
                                                    let branchObject = branch.value as? [String: AnyObject]
                                                    let BrLat = branchObject?["Latitude"]
                                                    let BrLong = branchObject?["Longitude"]
                                                    let BrSuburb = branchObject?["Suburb"]
                                                    
                                                    // This prints true for the snapshot that contains that value
                                                    // try tag the location in test_input and use it in the brackets
                                                    let schemes = NSLinguisticTagger.availableTagSchemes(forLanguage: "en_AU")
                                                    let tagger = NSLinguisticTagger(tagSchemes: schemes, options: 0)
                                                    let text = self.textField.text
                                                    tagger.string = text
                                                    
                                                    let range = NSRange(location:0, length: (text?.utf16.count)!)
                                                    let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
                                                    let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
                                                    
                                                    tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
                                                        
                                                        if let tag = tag, tags.contains(tag) {
                                                            let name = (text as! NSString).substring(with: tokenRange)
                                                            // Do something with the name
                                                            if((BrSuburb)?.contains(name))!
                                                            {
                                                                _ = (self.Branches.queryOrdered(byChild: "\(name)").queryEqual(toValue: "\(name)"))
                                                                self.textField.text = "\(BrLat!) \n \(BrLong!)"
                                                                let myString = self.textField.text
                                                                let new = myString?.replacingOccurrences(of: ",", with: ".")
                                                                self.textField.text = "\(new!)"
                                                                let lat = new?.components(separatedBy: "\n")[0]
                                                                let long = new?.components(separatedBy: "\n")[1]
                                                                print("LAT IS:", lat!)
                                                                print("LONG IS:", long!)
                                                                let LAT = (lat! as NSString).doubleValue
                                                                let LONG = (long! as NSString).doubleValue
                                                                let des = CLLocationCoordinate2DMake(LAT, LONG)
                                                                self.ShowRoute(sourceCoordinate: src, destiCoordinate: des)
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                            
                                        }
                                        // if the user asks for the closest store at a specific location, then display that stores (distance from the location), if they wish to go there, take them there.
                                        else if (keys["intent"]![0] == "Operation: closest"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0], keyword)
                                            print(s)
                                            test_output.append(contentsOf: s)
                                            self.Branches.observe(DataEventType.value, with: {(DataSnapshot) in
                                                
                                                for branch in DataSnapshot.children.allObjects as! [DataSnapshot] {
                                                    
                                                    let branchObject = branch.value as? [String: AnyObject]
                                                    let BrLat = branchObject?["Latitude"]
                                                    let BrLong = branchObject?["Longitude"]
                                                    let BrSuburb = branchObject?["Suburb"]
                                                    
                                                    // This prints true for the snapshot that contains that value
                                                    // try tag the location in test_input and use it in the brackets
                                                    let schemes = NSLinguisticTagger.availableTagSchemes(forLanguage: "en_AU")
                                                    let tagger = NSLinguisticTagger(tagSchemes: schemes, options: 0)
                                                    let text = self.textField.text
                                                    tagger.string = text
                                                    
                                                    let range = NSRange(location:0, length: (text?.utf16.count)!)
                                                    let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
                                                    let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
                                                    
                                                    tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
                                                        
                                                        if let tag = tag, tags.contains(tag) {
                                                            let name = (text as! NSString).substring(with: tokenRange)
                                                            // Do something with the name
                                                            if((BrSuburb)?.contains(name))!
                                                            {
                                                                self.textField.text = "\(name)"
                                                                print(name)
                                                                _ = (self.Branches.queryOrdered(byChild: "\(name)").queryEqual(toValue: "\(name)"))
                                                                self.textField.text = "\(BrLat!) \n \(BrLong!)"
                                                                let myString = self.textField.text
                                                                let new = myString?.replacingOccurrences(of: ",", with: ".")
                                                                self.textField.text = "\(new!)"
                                                                let lat = new?.components(separatedBy: "\n")[0]
                                                                let long = new?.components(separatedBy: "\n")[1]
                                                                let LAT = (lat! as NSString).doubleValue
                                                                let LONG = (long! as NSString).doubleValue
                                                                
                                                                let location = CLLocation(latitude: LAT, longitude: LONG)
                                                                self.fetchCityAndCountry(location: location) { city, country, error in
                                                                    guard let city = city, let country = country, error == nil else { return }
                                                                    let GeoCoder = CLGeocoder()
                                                                    GeoCoder.geocodeAddressString("\(city)")
                                                                    {
                                                                        placemarks, error in
                                                                        let placemark = placemarks?.first
                                                                        let lat = placemark?.location?.coordinate.latitude
                                                                        let lon = placemark?.location?.coordinate.longitude
                                                                        print("LATLONG FOR SUBURB Lat: \(lat!), Lon: \(lon!)")
                                                                        let loc2 = CLLocation(latitude: lat!, longitude: lon!)
                                                                        let distance = location.distance(from: loc2)
                                                                         self.textField.text = "The closest store to \(name) is about \(String(format: "%2.f", distance)) meters away"
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                        }
                                        // If a user asks for the information of a store, display it.
                                        else if (keys["intent"]![0] == "Operation: info"){
                                            let s = String(format:"Have %@ \n",keys["intent"]![0], keyword)
                                            print(s)
                                            test_output.append(contentsOf: s)
                                            self.Branches.observe(DataEventType.value, with: {(DataSnapshot) in
                                                
                                                for branch in DataSnapshot.children.allObjects as! [DataSnapshot] {
                                                    
                                                    let branchObject = branch.value as? [String: AnyObject]
                                                    let brAddress = branchObject?["Address"]
                                                    let brName = branchObject?["Branch Name"]
                                                    let BrPhNo = branchObject?["Branch Ph Number"]
                                                    let BrLat = branchObject?["Latitude"]
                                                    let BrLong = branchObject?["Longitude"]
                                                    let BrManager = branchObject?["Manager Name"]
                                                    let BrPostcode = branchObject?["Post code"]
                                                    let BrState = branchObject?["State"]
                                                    let BrSuburb = branchObject?["Suburb"]
                                                    
                                                    // This prints true for the snapshot that contains that value
                                                    // try tag the location in test_input and use it in the brackets
                                                    let schemes = NSLinguisticTagger.availableTagSchemes(forLanguage: "en_AU")
                                                    let tagger = NSLinguisticTagger(tagSchemes: schemes, options: 0)
                                                    
                                                    let text = self.textField.text
                                                    tagger.string = text
                                                    
                                                    let range = NSRange(location:0, length: (text?.utf16.count)!)
                                                    tagger.setOrthography(NSOrthography.defaultOrthography(forLanguage: "en_AU"), range: range)
                                                    let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
                                                    let tags: [NSLinguisticTag] = [.personalName, .placeName, .organizationName]
                                                    
                                                    tagger.enumerateTags(in: range, unit: .word, scheme: .nameType, options: options) { tag, tokenRange, stop in
                                                        
                                                        if let tag = tag, tags.contains(tag) {
                                                            let name = (text! as NSString).substring(with: tokenRange)
                                                            // Do something with the name
                                                            
                                                            if((BrSuburb)?.contains(name))!
                                                            {
                                                                self.textField.text = "\(name)"
                                                                print(name)
                                                                _ = (self.Branches.queryOrdered(byChild: "\(name)").queryEqual(toValue: "\(name)"))
                                                                // brAddress, brName, BrPhNo, BrLat, BrLong, BrManager, BrPostcode, BrState, BrSuburb
                                                                self.textField.text = "Address: \(brAddress!) \nBranch Name: \(brName!) \nPhone Number: \(BrPhNo!) \nLatitude: \(BrLat!) \nLongitude: \(BrLong!) \nBranch Manager: \(BrManager!) \nPostcode: \(BrPostcode!) \nState: \(BrState!) \nSuburb: \(BrSuburb!)"
                                                            }
                                                        }
                                                    }
                                                }
                                            })
                                        }
                                        
                                            
                                        else {
                                            print("Error!")// #useless. This line doesn't make any sence.
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        })

        // start audio node and begin recording
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recogntionRequest?.append(buffer)
        }
        // prepare audio engine
        audioEngine.prepare()
        
        // try start audio engine, if it cant, tell the user what went wrong.
        do {
            try audioEngine.start()
        } catch {
            print("Audio Engine cant start")
        }
    }
    
    // check if the button has been pressed
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            talkButton2.isEnabled = true
        } else {
            talkButton2.isEnabled = false
        }
    }
}

